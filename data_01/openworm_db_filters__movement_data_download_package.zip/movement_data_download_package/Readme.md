Change permissions of download_zenodo.sh first - chmod 755 download_zenodo.sh
Usage: ./download_zenodo.sh <data file> <output folder>
